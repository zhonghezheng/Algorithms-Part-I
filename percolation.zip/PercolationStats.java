import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private double[] record;
    private int T;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        record = new double[trials];
        Percolation a;
        T = trials;

        for (int i = 0; i < record.length; i++) {
            a = new Percolation(n);

            while (!a.percolates()) {
                a.open(StdRandom.uniform(n) + 1, StdRandom.uniform(n) + 1);
            }

            record[i] = a.numberOfOpenSites() / (double) (n * n);
        }

    }

    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(record);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(record);

    }


    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return (mean() - 1.96 * stddev() / Math.sqrt(T));

    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return (mean() + 1.96 * stddev() / Math.sqrt(T));

    }

    // test client (see below)
    public static void main(String[] args) {
        
        int N = StdIn.readInt();
        int T = StdIn.readInt();

        if (N < 1 || T < 1) {
            throw new IllegalArgumentException();
        }
        PercolationStats a = new PercolationStats(N, T);
        StdOut.println("mean = " + a.mean());
        StdOut.println("stddev = " + a.stddev());
        StdOut.println("95% confidence interval = [" + a.confidenceLo() + "," + a.confidenceHi() + "]");

    }

}
