import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private WeightedQuickUnionUF grid;
    private static int N;
    private boolean[] open;
    private int count;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        count = 0;
        grid = new WeightedQuickUnionUF(n * n + 2);
        open = new boolean[n * n + 2];
        open[0] = true;
        open[n * n + 1] = true;

        for (int i = 1; i <= n * n + 1; i++) {
            open[i] = false;
        }
        N = n;
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row > N || col > N || row <= 0 || col <= 0) {
            throw new IllegalArgumentException();
        }
        if (open[(row - 1) * N + col]) {
            return;
        }
        open[(row - 1) * N + col] = true;

        //update open sites
        count++;
        //right
        if (col < N && open[(row - 1) * N + col + 1])
            grid.union((row - 1) * N + col, (row - 1) * N + col + 1);
        //left
        if (col > 1 && open[(row - 1) * N + col - 1])
            grid.union((row - 1) * N + col, (row - 1) * N + col - 1);
        //up
        if (row > 1 && open[(row - 2) * N + col])
            grid.union((row - 2) * N + col, (row - 1) * N + col);
            //connects top site with grid[0]
        else if (row == 1) {
            grid.union(0, (row - 1) * N + col);
        }
        //down
        if (row < N && open[(row) * N + col])
            grid.union((row) * N + col, (row - 1) * N + col);
            //connects bottom site with grid[N*N+1]
        else if (row == N) {
            grid.union(N * N + 1, (row - 1) * N + col);
        }


    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row > N || col > N || row <= 0 || col <= 0) {
            throw new IllegalArgumentException();
        } else
            return open[(row - 1) * N + col];

    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row > N || col > N || row <= 0 || col <= 0) {
            throw new IllegalArgumentException();
        } else
            return grid.connected(0, (row - 1) * N + col);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return count;

    }

    // does the system percolate?
    public boolean percolates() {
        return grid.connected(0, N * N + 1);
    }

    // test client (optional)
    public static void main(String[] args) {

    }
}
