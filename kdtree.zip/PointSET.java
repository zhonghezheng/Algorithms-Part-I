import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;

import java.util.ArrayList;
import java.util.TreeSet;

public class PointSET {

    private TreeSet<Point2D> tree;

    public PointSET() {
        tree = new TreeSet<>();

    }// construct an empty set of points

    public boolean isEmpty() {
        return tree.isEmpty();
    }// is the set empty?

    public int size() {
        return tree.size();

    }// number of points in the set

    public void insert(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException();
        }
        tree.add(p);

    }// add the point to the set (if it is not already in the set)

    public boolean contains(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException();
        }

        return tree.contains(p);
    }// does the set contain point p?

    public void draw() {
        for (Point2D e : tree) {
            e.draw();
        }
    }// draw all points to standard draw

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) {
            throw new IllegalArgumentException();
        }

        ArrayList<Point2D> in = new ArrayList<>();

        for (Point2D e : tree) {
            if (e.x() >= rect.xmin() && e.x() <= rect.xmax() && e.y() >= rect.ymin()
                    && e.y() <= rect
                    .ymax()) {
                in.add(e);
            }
        }

        return in;
    }// all points that are inside the rectangle (or on the boundary)

    public Point2D nearest(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException();
        }

        if (tree.isEmpty()) {
            return null;
        }

        double min = Integer.MAX_VALUE;
        Point2D minP = new Point2D(0, 0);

        for (Point2D e : tree) {
            if (e.distanceTo(p) < min) {
                min = e.distanceTo(p);
                minP = e;
            }
        }

        return minP;
    }// a nearest neighbor in the set to point p; null if the set is empty

    public static void main(String[] args) {
    }// unit testing of the methods (optional)

}
