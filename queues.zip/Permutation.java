import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;

public class Permutation {
    public static void main(String[] args) {

        RandomizedQueue test = new RandomizedQueue();

        while (!StdIn.isEmpty()) {
            String s = StdIn.readString();
            while (s.contains(" ")) {
                String sub = s.substring(0, s.indexOf(' '));
                s = s.substring(s.indexOf(' ') + 1);
                test.enqueue(sub);
            }

            test.enqueue(s);
        }

        int k = 0;
        if (args[0].matches("(\\d+)")) {
            k = Integer.parseInt(args[0]);
        }

        Iterator interator = test.iterator();

        for (int i = 0; i < k; i++) {
            StdOut.println(interator.next());
        }
    }
}
