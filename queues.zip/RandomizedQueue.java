import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;

public class RandomizedQueue<Item> implements Iterable<Item> {

    private Item[] list;
    private int[] empty;
    private int count;
    private int listPointer;
    private int emptyPointer;

    // construct an empty randomized queue
    public RandomizedQueue() {
        list = (Item[]) new Object[1];
        empty = new int[1];
        count = 0;
        listPointer = 0;
        emptyPointer = 0;
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return count == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return count;

    }

    // add the item
    public void enqueue(Item item) {

        if (item == null) {
            throw new IllegalArgumentException();
        }
        //if empty at random position in list
        if (empty[0] != 0) {
            list[empty[0]] = item;

            int i = 0;
            while (empty[i] != 0 && i < empty.length - 1) {
                empty[i] = empty[i + 1];
                i++;
            }

            if (i == empty.length - 1) {
                empty[i] = 0;
            }
        }

        //if list is full
        else if (listPointer == list.length) {
            Item[] temp = (Item[]) new Object[list.length * 2];
            for (int i = 0; i < list.length; i++) {
                temp[i] = list[i];
            }
            list = temp;
            list[listPointer] = item;
            listPointer += 1;
        }

        //regular add
        else {
            list[listPointer] = item;
            listPointer += 1;
        }

        count++;

    }

    // remove and return a random item
    public Item dequeue() {
        if (count == 0) {
            throw new java.util.NoSuchElementException();
        }
        int a = StdRandom.uniform(0, listPointer);

        while (list[a] == null) {
            a = StdRandom.uniform(0, listPointer);
        }
        Item b = list[a];
        list[a] = null;

        //if empty is full
        if (emptyPointer == empty.length) {
            int[] temp = new int[empty.length * 2];
            for (int i = 0; i < empty.length; i++) {
                temp[i] = empty[i];
            }
            empty = temp;
        }

        empty[emptyPointer] = a;

        emptyPointer += 1;

        count -= 1;

        return b;

    }


    // return a random item (but do not remove it)
    public Item sample() {
        if (count == 0) {
            throw new java.util.NoSuchElementException();
        }
        else
            return list[StdRandom.uniform(0, listPointer)];

    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        Iterator<Item> a = new Iterator<Item>() {
            int tracker = 0;
            boolean[] called = new boolean[list.length];

            public boolean hasNext() {
                return tracker != count;
            }

            public Item next() {
                if (tracker == count) {
                    throw new java.util.NoSuchElementException();
                }

                int random = StdRandom.uniform(0, listPointer);

                while (called[random] || list[random] == null) {
                    random = StdRandom.uniform(0, listPointer);
                }

                called[random] = true;
                tracker += 1;

                return list[random];
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };

        return a;

    }

    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
        rq.enqueue(14);
        rq.dequeue();
        rq.enqueue(26);
        rq.dequeue();
        rq.enqueue(31);
        rq.dequeue();
        rq.enqueue(33);
        rq.size();
        rq.dequeue();
    }

}
