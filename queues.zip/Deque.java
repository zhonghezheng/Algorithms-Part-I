import java.util.Iterator;

public class Deque<Item> implements Iterable<Item> {

    private Item[] listFront;
    private Item[] listBack;
    private int front;
    private int back;

    // construct an empty deque
    public Deque() {
        listFront = (Item[]) new Object[1];
        listBack = (Item[]) new Object[1];
        front = 0;
        back = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return front == 0 && back == 0;
    }

    // return the number of items on the deque
    public int size() {
        return front + back;
    }

    // add the item to the front
    public void addFirst(Item item) {

        if (item == null)
            throw new IllegalArgumentException();

        //resizing, double size
        if (front == listFront.length) {
            Item[] a = (Item[]) new Object[listFront.length * 2];

            for (int i = 0; i < listFront.length; i++) {
                a[i] = listFront[i];
            }

            listFront = a;
        }

        listFront[front] = item;
        front++;

    }

    // add the item to the back
    public void addLast(Item item) {
        if (item == null)
            throw new IllegalArgumentException();

        //resizing, double size
        if (back == listBack.length) {
            Item[] a = (Item[]) new Object[listBack.length * 2];

            for (int i = 0; i < listBack.length; i++) {
                a[i] = listBack[i];
            }

            listBack = a;
        }

        listBack[back] = item;
        back++;
    }

    // remove and return the item from the front
    public Item removeFirst() {

        if (front == 0 && back == 0) {
            throw new java.util.NoSuchElementException();
        }

        //if empty
        if (front == 0) {

            Item[] temp = (Item[]) new Object[back / 2 + 1];
            //transfer half of listBack to listFront
            for (int i = 0; i < back / 2 + 1; i++) {
                temp[i] = listBack[back / 2 - i];
                listBack[back / 2 - i] = null;
            }

            listFront = temp;
            front = back / 2 + 1;

            for (int i = 0; i < back - back / 2 - 1; i++) {
                listBack[i] = listBack[back / 2 + i + 1];
                listBack[back / 2 + i + 1] = null;
            }

            back = listBack.length - listBack.length / 2 - 1;
        }

        front -= 1;
        Item a = listFront[front];
        listFront[front] = null;
        return a;

    }

    // remove and return the item from the back
    public Item removeLast() {

        if (front == 0 && back == 0) {
            throw new java.util.NoSuchElementException();
        }

        //if empty
        if (back == 0) {

            Item[] temp = (Item[]) new Object[front / 2 + 1];

            //transfer half of listFront to listBack
            for (int i = 0; i < front / 2 + 1; i++) {
                temp[i] = listFront[front / 2 - i];
                listFront[front / 2 - i] = null;
            }

            listBack = temp;
            back = front / 2 + 1;

            for (int i = 0; i < front - front / 2 - 1; i++) {
                listFront[i] = listFront[front / 2 + i - 1];
                listFront[front / 2 + i - 1] = null;
            }

            front = listFront.length - listFront.length / 2 - 1;
        }

        back -= 1;
        Item a = listBack[back];
        listBack[back] = null;
        return a;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        Iterator<Item> a = new Iterator<Item>() {
            int currentfront = front;
            int currentback = -1;

            public boolean hasNext() {
                return !(currentfront == 0 && currentback == back - 1);
            }

            public Item next() {

                if (currentfront != 0) {
                    currentfront -= 1;
                    if (listFront[currentfront] == null) {
                        throw new java.util.NoSuchElementException();
                    }
                    else
                        return listFront[currentfront];
                }

                else {
                    currentback += 1;
                    if (listBack[currentback] == null || (currentback == (back)))
                        throw new java.util.NoSuchElementException();
                    else
                        return listBack[currentback];
                }

            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };

        return a;
    }

    // unit testing (required)
    public static void main(String[] args) {
        Deque<Integer> deque = new Deque<Integer>();
        deque.addLast(1);
        deque.addFirst(2);
        deque.removeFirst();
        deque.addLast(4);
        deque.removeLast();
        deque.removeLast();
        deque.size();
        deque.addFirst(8);
        deque.removeLast();
    }

}
