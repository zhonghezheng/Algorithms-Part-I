public class BruteCollinearPoints {
    private LineSegment[] track;
    private int pointer;

    public BruteCollinearPoints(Point[] points) {
        if (points == null || points.length < 4) {
            throw new IllegalArgumentException();
        }
        track = new LineSegment[points.length];
        pointer = 0;

        //check each point with each other
        for (int i = 0; i < points.length; i++) {

            if (points[i] == null) {
                throw new IllegalArgumentException();
            }

            for (int j = i + 1; j < points.length; j++) {

                if (points[j] == null) {
                    throw new IllegalArgumentException();
                }

                for (int k = j + 1; k < points.length; k++) {

                    if (points[k] == null) {
                        throw new IllegalArgumentException();
                    }

                    for (int m = k + 1; m < points.length; m++) {

                        if (points[m] == null) {
                            throw new IllegalArgumentException();
                        }

                        if (points[i].slopeTo(points[j]) == Double.NEGATIVE_INFINITY
                                || points[i].slopeTo(points[k]) == Double.NEGATIVE_INFINITY
                                || points[i].slopeTo(points[m]) == Double.NEGATIVE_INFINITY) {
                            throw new IllegalArgumentException();
                        }

                        if (points[j].slopeTo(points[k]) == Double.NEGATIVE_INFINITY
                                || points[j].slopeTo(points[m]) == Double.NEGATIVE_INFINITY) {
                            throw new IllegalArgumentException();
                        }

                        if (points[k].slopeTo(points[m]) == Double.NEGATIVE_INFINITY) {
                            throw new IllegalArgumentException();
                        }

                        double a = points[i].slopeTo(points[j]);
                        double b = points[j].slopeTo(points[k]);
                        double c = points[k].slopeTo(points[m]);

                        if (a == b && b == c) {
                            int smallest;
                            int biggest;

                            if (points[i].compareTo(points[j]) > 0
                                    && points[i].compareTo(points[k]) > 0
                                    && points[i].compareTo(points[m]) > 0) {
                                biggest = i;
                            }

                            else if (points[j].compareTo(points[i]) > 0
                                    && points[j].compareTo(points[k]) > 0
                                    && points[j].compareTo(points[m]) > 0) {
                                biggest = j;
                            }

                            else if (points[m].compareTo(points[i]) > 0
                                    && points[m].compareTo(points[j]) > 0
                                    && points[m].compareTo(points[k]) > 0) {
                                biggest = m;
                            }

                            else {
                                biggest = k;
                            }


                            if (points[i].compareTo(points[j]) < 0
                                    && points[i].compareTo(points[k]) < 0
                                    && points[i].compareTo(points[m]) < 0) {
                                smallest = i;
                            }

                            else if (points[j].compareTo(points[i]) < 0
                                    && points[j].compareTo(points[k]) < 0
                                    && points[j].compareTo(points[m]) < 0) {
                                smallest = j;
                            }

                            else if (points[m].compareTo(points[i]) < 0
                                    && points[m].compareTo(points[j]) < 0
                                    && points[m].compareTo(points[k]) < 0) {
                                smallest = m;
                            }

                            else {
                                smallest = k;
                            }

                            LineSegment x = new LineSegment(points[smallest], points[biggest]);
                            boolean exist = false;

                            b:
                            for (int y = 0; y < pointer; y++) {
                                if (track[y] == x) {
                                    exist = true;
                                    break b;
                                }
                            }

                            if (!exist) {
                                track[pointer] = x;
                                pointer++;
                            }
                        }
                    }
                }
            }
        }
    }

    public int numberOfSegments() {
        return pointer;

    }

    public LineSegment[] segments() {
        LineSegment[] temp = new LineSegment[pointer];
        for (int i = 0; i < pointer; i++) {
            temp[i] = track[i];
        }
        return temp;

    }

    /*public static void main(String[] asdf) {
        BruteCollinearPoints a = new BruteCollinearPoints(new Point[] {
                new Point(14452, 9746), new Point(31572, 20345), new Point(31572, 20345),
                //new Point(7, 7), new Point(5, 5), new Point(4, 4), new Point(6, 6)
        });

        LineSegment[] temp = a.segments();

        for (int i = 0; i < temp.length; i++) {
            StdOut.println(temp[i]);
        }
    }*/
}
