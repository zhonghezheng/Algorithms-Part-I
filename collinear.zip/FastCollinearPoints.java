import java.util.Arrays;

public class FastCollinearPoints {

    private LineSegment[] track;
    private int pointer;

    public FastCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException();
        }

        track = new LineSegment[points.length * 4];
        pointer = 0;

        for (int i = 0; i < points.length; i++) {
            Point[] slopes = new Point[points.length - 1];

            int j = 0;
            boolean skip = false;
            while (j < points.length) {
                if (points[j] == null) {
                    throw new IllegalArgumentException();
                }

                if (j != i && !skip) {
                    slopes[j] = (points[j]);
                }

                else if (j != i && skip) {
                    slopes[j - 1] = points[j];
                }

                else {
                    skip = true;
                }

                j += 1;
            }

            Arrays.sort(slopes, points[i].slopeOrder());

            int k = 0;
            int count = 0;

            if (slopes[0].slopeTo(points[i]) == Double.NEGATIVE_INFINITY) {
                throw new IllegalArgumentException();
            }

            while (k < slopes.length - 1) {
                if (slopes[k + 1].slopeTo(points[i]) == slopes[k].slopeTo(points[i])) {
                    count++;
                }

                if (((slopes[k + 1].slopeTo(points[i]) != slopes[k].slopeTo(points[i])
                        || (slopes[k + 1].slopeTo(points[i]) == slopes[k].slopeTo(points[i]) && (k
                        == slopes.length - 2))) && count >= 2)) {

                    if (slopes[k + 1].slopeTo(points[i]) == slopes[k].slopeTo(points[i])) {
                        k += 1;
                    }

                    boolean endpoint = true;

                    a:
                    for (int m = 0; m <= k - count; m++) {
                        if (slopes[m].slopeTo(points[i]) == -slopes[k].slopeTo(points[i])
                                && slopes[m].slopeTo(points[i]) != 0) {
                            endpoint = false;
                            break a;
                        }
                    }

                    if (endpoint) {
                        Point smallest = points[i];
                        Point biggest = points[i];

                        for (j = k - count; j <= k; j++) {
                            if (smallest.compareTo(slopes[j]) == 1) {
                                smallest = slopes[j];
                            }

                            if (biggest.compareTo(slopes[j]) == -1) {
                                biggest = slopes[j];
                            }
                        }

                        if (k == slopes.length - 2 && slopes[k + 1].slopeTo(points[i]) == slopes[k]
                                .slopeTo(points[i])) {
                            if (smallest.compareTo(slopes[j]) == 1) {
                                smallest = slopes[j];
                            }

                            if (biggest.compareTo(slopes[j]) == -1) {
                                biggest = slopes[j];
                            }
                        }

                        LineSegment x = new LineSegment(smallest, biggest);
                        boolean exist = false;

                        b:
                        for (int y = 0; y < pointer; y++) {
                            if (track[y].toString().equals(x.toString())) {
                                exist = true;
                                break b;
                            }
                        }

                        if (!exist) {
                            track[pointer] = x;
                            pointer++;
                        }
                    }

                    count = 0;
                }

                else if ((slopes[k + 1].slopeTo(points[i]) != slopes[k].slopeTo(points[i])))
                    count = 0;

                k++;
            }
        }

    }


    public int numberOfSegments() {
        return pointer;
    }

    public LineSegment[] segments() {
        LineSegment[] temp = new LineSegment[pointer];
        for (int i = 0; i < pointer; i++) {
            temp[i] = track[i];
        }
        return temp;
    }

    /*public static void main(String asdf[]) {
        FastCollinearPoints a = new FastCollinearPoints(
                new Point[] {
                        //new Point(1, 10), new Point(1, 9), new Point(1, 8), new Point(1, 7),
                        new Point(0, 3), new Point(1, 3), new Point(2, 3), new Point(3, 3),
                        //new Point(15, 15), new Point(16, 16), new Point(20, 20), new Point(25, 25)
                });
        LineSegment[] temp = a.segments();

        for (int i = 0; i < temp.length; i++) {
            StdOut.println(temp[i]);
        }
    }*/
}
