import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Comparator;

public class Solver {

    private boolean solvable;
    private ArrayList<Board> path;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException();
        }
        class Node {
            Board board;
            Node prev;
            int moves;
            int mValue;

            public Node(Board a, Node b, int c) {
                board = a;
                prev = b;
                moves = c;
                mValue = a.manhattan();
            }
        }

        MinPQ<Node> queue = new MinPQ<>(new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                return o1.moves + o1.mValue - o2.moves - o2.mValue;
            }
        });
        MinPQ<Node> queue2 = new MinPQ<>(new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                return o1.moves + o1.mValue - o2.moves - o2.mValue;
            }
        });

        queue.insert(new Node(initial, null, 0));
        queue2.insert(new Node(initial.twin(), null, 0));

        solvable = false;
        Node solution;

        a:
        while (true) {
            Node prev = queue.delMin();
            Node prevTwin = queue2.delMin();

            if (prev.board.isGoal()) {
                solvable = true;
                solution = prev;
                break a;
            }

            if (prevTwin.board.isGoal()) {
                solution = prevTwin;
                break a;
            }


            for (Board e : prev.board.neighbors()) {
                if (prev.prev != null && e.equals(prev.prev.board))
                    continue;
                else
                    queue.insert(new Node(e, prev, prev.moves + 1));
            }

            for (Board e : prevTwin.board.neighbors()) {
                if (prevTwin.prev != null && e.equals(prevTwin.prev.board))
                    continue;
                else
                    queue2.insert(new Node(e, prevTwin, prevTwin.moves + 1));

            }
        }

        path = new ArrayList<>();
        while (solvable && solution.prev != null) {
            path.add(solution.board);
            solution = solution.prev;
        }

        path.add(solution.board);
    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return solvable;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!solvable) {
            return -1;
        }
        return path.size() - 1;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!solvable) {
            return null;
        }

        ArrayList<Board> a = new ArrayList<>();

        for (int i = 0; i < path.size(); i++) {
            a.add(path.get(path.size() - i - 1));
        }

        return a;
    }

    // test client (see below)
    /*public static void main(String[] args) {

        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }*/

    public static void main(String asdf[]) {
        int[][] temp = new int[3][3];
        temp[0][0] = 1;
        temp[0][1] = 0;
        temp[0][2] = 2;
        temp[1][0] = 7;
        temp[1][1] = 5;
        temp[1][2] = 4;
        temp[2][0] = 8;
        temp[2][1] = 6;
        temp[2][2] = 3;

        Solver a = new Solver(new Board(temp));

        for (Board e : a.solution()) {
            StdOut.println(e);
        }
    }

}
