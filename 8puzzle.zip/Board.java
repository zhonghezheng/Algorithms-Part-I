import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class Board {
    private int[][] tiles;
    private ArrayList<Board> neighbors;
    private int priority;


    private int n;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {
        if (tiles == null) {
            throw new IllegalArgumentException();
        }

        n = tiles.length;
        this.tiles = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                this.tiles[i][j] = tiles[i][j];
            }
        }
        n = tiles.length;
    }

    // string representation of this board
    public String toString() {
        StringBuilder a = new StringBuilder();

        a.append(n + "\n");

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a.append(tiles[i][j] + " ");
            }
            a.append("\n");

        }

        return a.toString();
    }

    // board dimension n
    public int dimension() {
        return n;
    }

    // number of tiles out of place
    public int hamming() {
        int count = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] != i * n + j + 1) {
                    count += 1;
                }
            }
        }

        return count - 1;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        int count = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] != 0) {
                    int row = i;
                    int col = j;

                    if (tiles[i][j] < row * n + col + 1) {
                        while (row != 0 && (row) * n + 1 > tiles[i][j]) {
                            row -= 1;
                            count++;
                        }

                        while (tiles[i][j] > row * n + col + 1) {
                            col += 1;
                            count++;

                        }

                        while (tiles[i][j] < row * n + col + 1 && col != 0) {
                            col -= 1;
                            count++;
                        }
                    }

                    else if (tiles[i][j] > row * n + col + 1) {
                        while (row != n - 1 && (row + 1) * n + 1 <= tiles[i][j]) {
                            row += 1;
                            count++;
                        }

                        while (tiles[i][j] > row * n + col + 1) {
                            col += 1;
                            count++;

                        }

                        while (tiles[i][j] < row * n + col + 1) {
                            col -= 1;
                            count++;
                        }
                    }
                }
            }


        }

        return count;
    }

    // is this board the goal board?
    public boolean isGoal() {

        boolean isGoal = true;
        a:
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == n - 1 && j == n - 1) {
                    if (tiles[i][j] != 0) {
                        isGoal = false;
                    }
                }

                else {
                    if (tiles[i][j] != i * n + j + 1) {
                        isGoal = false;
                        break a;
                    }
                }

            }
        }

        return isGoal;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == null || y.getClass() != Board.class) {
            return false;
        }
        Board b = (Board) y;
        return Arrays.deepEquals(this.tiles, b.tiles);
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {

        neighbors = new ArrayList<>();

        int row = 0;
        int col = 0;

        b:
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] == 0) {
                    row = i;
                    col = j;
                    break b;
                }

            }


        }

        if (row != 0) {
            int[][] New = new int[n][n];

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    New[i][j] = tiles[i][j];
                }
            }
            int temp = New[row - 1][col];
            New[row - 1][col] = New[row][col];
            New[row][col] = temp;

            neighbors.add(new Board(New));
        }

        if (row != n - 1) {
            int[][] New = new int[n][n];

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    New[i][j] = tiles[i][j];
                }
            }

            int temp = New[row + 1][col];
            New[row + 1][col] = New[row][col];
            New[row][col] = temp;

            neighbors.add(new Board(New));
        }

        if (col != 0) {
            int[][] New = new int[n][n];

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    New[i][j] = tiles[i][j];
                }
            }

            int temp = New[row][col - 1];
            New[row][col - 1] = New[row][col];
            New[row][col] = temp;

            neighbors.add(new Board(New));
        }

        if (col != n - 1) {
            int[][] New = new int[n][n];

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    New[i][j] = tiles[i][j];
                }
            }

            int temp = New[row][col + 1];
            New[row][col + 1] = New[row][col];
            New[row][col] = temp;

            neighbors.add(new Board(New));
        }

        return neighbors;
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        int row1 = 0;
        int col1 = 0;
        int row2 = n - 1;
        int col2 = n - 1;

        if (tiles[row1][col1] == 0) {
            row1 = 0;
            col1 = n - 1;
        }

        else if (tiles[row2][col2] == 0) {
            row2 = 0;
            col2 = n - 1;
        }

        int[][] New = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                New[i][j] = tiles[i][j];
            }
        }

        New[row1][col1] = tiles[row2][col2];
        New[row2][col2] = tiles[row1][col1];

        return new Board(New);
    }

    // unit testing (not graded)
    public static void main(String[] args) {
        int[][] array = new int[3][3];
        array[0][0] = 4;
        array[0][1] = 7;
        array[0][2] = 3;
        array[1][0] = 1;
        array[1][1] = 0;
        array[1][2] = 8;
        array[2][0] = 5;
        array[2][1] = 6;
        array[2][2] = 2;

        Board a = new Board(array);

        StdOut.println(a.n);
        StdOut.println(a.hamming());
        StdOut.println(a.manhattan());

        for (Board e : a.neighbors()) {
            StdOut.println(e);
        }

        StdOut.println(a.manhattan());

        a.equals("Hi");

    }

}
